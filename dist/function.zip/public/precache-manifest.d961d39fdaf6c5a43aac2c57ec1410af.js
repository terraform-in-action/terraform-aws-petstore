self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1d50c91cd13b201f64c043097d2bf0ee",
    "url": "./ui/index.html"
  },
  {
    "revision": "9d35a34ae2923739954d",
    "url": "./ui/static/js/2.dac4b64e.chunk.js"
  },
  {
    "revision": "879b16d687fe847b0ca9becae49bebfa",
    "url": "./ui/static/js/2.dac4b64e.chunk.js.LICENSE"
  },
  {
    "revision": "dd6ea5f776a67f17be30",
    "url": "./ui/static/js/main.1c60cd3a.chunk.js"
  },
  {
    "revision": "bb2dbb964886b571636a",
    "url": "./ui/static/js/runtime-main.c7f2f0f5.js"
  }
]);